"""Rankers init"""
